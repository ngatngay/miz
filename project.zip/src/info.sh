echo "info"
ehw "="

apache2 -v
echo "----------"

mariadb -V
echo "----------"

php -v

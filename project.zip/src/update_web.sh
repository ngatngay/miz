#!/bin/bash

php /www/miz/src/update_web.php

<?php

defined('ACCESS') or exit('Not access'); 

$site_end = $site_end ?? '';
?>

</div>

<?= $site_end ?>

</body>
</html>
